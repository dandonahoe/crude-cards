import { Env } from '@app/Env';
import { PrismaClient } from '@prisma/client';


const DATABASE_CONNECTION_STRING = Env.getValue<string>('DATABASE_CONNECTION_STRING');

const Prisma = new PrismaClient({
    datasources : {
        db : {
            url : DATABASE_CONNECTION_STRING,
        },
    },
});

// eslint-disable-next-line import/no-default-export
export default Prisma;
