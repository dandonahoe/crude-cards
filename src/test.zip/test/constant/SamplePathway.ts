
import { MakePathway } from '@app/constant/default/DefaultPathway';
import { CoreHash } from '@app/type/framework/core/CoreHash';


export const pathwayHash : CoreHash = 'pathway-123';

// Generate PathwayModel
export const SamplePathway = MakePathway({
    id   : pathwayHash as unknown as number,
    hash : pathwayHash,
});
