import { UserType } from '@app/constant/enum/model/UserTypeEnum';
import { PathwayConfigType } from '@app/type/config/PathwayConfigType';


/* eslint-disable max-len */

export const PathwayConfig : PathwayConfigType = {
    milestoneConfig : [{
        order      : 0,
        hash       : 'milestone-000',
        logic      : 'To conduct initial research on the invention idea and to determine if it is patentable.',
        taskConfig : [{
            condition  : 'OnStart',
            order      : 0,
            hash       : 'task-000',
            userType   : UserType.Client,
            logic      : 'Welcome them to the platform and tell them about the process. Mention who their attorney is and how to contact them.',
            onComplete : 'Leave feedback to the Client telling them good job and encouraging them.',
        }, {
            condition  : 'OnStart',
            order      : 1,
            hash       : 'task-111',
            userType   : UserType.Client,
            logic      : 'Have them send their attorney a message to help understand the process. This will help the attorney and client understand each other better',
            onComplete : 'Close the task. Assign a task to the attorney to review the message and respond.',
        }, {
            condition  : 'OnStart',
            order      : 2,
            hash       : 'task-222',
            userType   : UserType.Business,
            logic      : 'Have them complete the intake form explaining their idea.',
            onComplete : 'Assign a new task to review the Client\'s intake form with their attorney. Mention a list of questions to ask based on the answers to the form.',
        }],
    }, {
        order      : 1,
        hash       : 'milestone-222',
        logic      : 'To prepare and file a patent application.',
        taskConfig : [{
            condition  : 'OnStart',
            order      : 0,
            hash       : 'task-333',
            userType   : UserType.Client,
            logic      : 'Have them review and approve the patent application draft.',
            onComplete : 'Assign a task to the attorney to file the patent application.',
        }, {
            condition  : 'OnStart',
            order      : 1,
            hash       : 'task-444',
            userType   : UserType.Client,
            logic      : 'Have them pay the patent application filing fee.',
            onComplete : 'Confirm receipt of the payment and file the patent application.',
        }, {
            condition  : 'OnStart',
            order      : 2,
            hash       : 'task-555',
            userType   : UserType.Client,
            logic      : 'Have them review the filed patent application and confirm.',
            onComplete : 'Close the task. Notify the client of the patent application filing date.',
        }],
    }, {
        order      : 2,
        hash       : 'milestone-333',
        logic      : 'To respond to the patent office actions.',
        taskConfig : [{
            condition  : 'OnStart',
            order      : 0,
            hash       : 'task-666',
            userType   : UserType.Client,
            logic      : 'Have them review the patent office actions and discuss with the attorney.',
            onComplete : 'Assign a task to the attorney to prepare a response.',
        }, {
            onComplete : 'Assign a task to the attorney to file the response.',
            userType   : UserType.Client,
            condition  : 'OnStart',
            logic      : 'Have them review and approve the response to the patent office actions.',
            order      : 1,
            hash       : 'task-777',
        }, {
            condition  : 'OnStart',
            order      : 2,
            hash       : 'task-888',
            userType   : UserType.Client,
            logic      : 'Have them pay the fee for responding to the patent office actions.',
            onComplete : 'Confirm receipt of the payment and file the response.',
        }],
    }],
};

/* eslint-enable max-len */

