export const UnserializableList = [
    () => {},
    function namedFunc() {},
];
