import { valueToString } from '@app/server/Convert/ConvertUtil';
import { TestType } from '@app/shared/TypeTest';
import { MockData } from '@app/test/MockData';


// but who tests the test data?

describe('MockData tests. Testing that test data is proper.', () => {

    MockData.Number.Valid.List.forEach(input => {
        it(`should be a valid number (${valueToString(input)})`, () => {

            const num = Number(input);
            expect(isNaN(num)).toBeFalsy();
        });
    });

    MockData.String.Valid.List.forEach(input => {
        it(`should convert to a string successfully (${valueToString(input)})`, () => {

            expect(String(input)).toBe(input);
        });
    });

    MockData.JSON.Valid.List.forEach(input => {
        it(`should parse successfully as JSON (${valueToString(input)})`, () => {

            expect(() => JSON.parse(input)).not.toThrow();
        });
    });

    MockData.Number.Valid.BoundaryValueList.forEach(input => {
        it(`should be within JavaScript number limits (${valueToString(input)})`, () => {

            const num = Number(input);

            // Check if number is a safe integer or is positive/negative infinity
            const isValid = Number.isSafeInteger(num) || num === Infinity || num === -Infinity;

            // Expect it to be valid
            expect(isValid).toBe(true);
        });
    });

    MockData.Number.Invalid.BoundaryValueList.forEach(input => {
        it(`should not be acceptable (${valueToString(input)})`, () => {
            // Ensure the number is NaN or out of the safe integer range

            const isInvalid = Number.isNaN(input) || input < Number.MIN_SAFE_INTEGER || input > Number.MAX_SAFE_INTEGER;

            // Expect it to be invalid
            expect(isInvalid).toBe(true);
        });
    });

    // Test for string data
    MockData.String.Valid.List.forEach(input => {
        it(`should validate that the values are correctly typed string (${valueToString(input)})`, () => {
        // Check if the type of the input is 'string'
            const isString = typeof input === 'string';
            // Expect it to be string
            expect(isString).toBe(true);
        });
    });

    // Test for boolean data
    MockData.Boolean.Valid.List.forEach(input => {
        it(`should validate that the values are correctly typed boolean (${valueToString(input)})`, () => {
        // Check if the type of the input is 'boolean'
            const isBoolean = typeof input === 'boolean';
            // Expect it to be boolean
            expect(isBoolean).toBe(true);
        });
    });


    MockData.SpecialCharacterList.forEach(input => {
        it(`should validate that the value is a special character (${input})`, () => {
            // Check if the type of the input is 'string'
            const isString = typeof input === 'string';
            // Check if the length of the string is 1
            const isSingleCharacter = Array.from(input).length === 1;

            // Expect it to be a string
            expect(isString).toBe(true);
            // Expect it to be a single character
            expect(isSingleCharacter).toBe(true);
        });
    });

    MockData.Boolean.Valid.List.forEach(input => {
        it(`should validate that the values are correctly typed boolean (${valueToString(input)})`, () => {

            // Check if the type of the input is 'boolean'
            const isBoolean = typeof input === 'boolean';

            // Expecting the type to be boolean
            expect(isBoolean).toBeTruthy();
        });
    });

    MockData.String.Invalid.UnconvertableToStringList.forEach(input => {
        it(`should validate UnconvertableToString (${valueToString(input)})`, () => {


            expect(TestType.isConvertableToString(input)).toBeFalsy();
        });
    });

    MockData.Date.Valid.List.forEach(input => {
        it(`should validate ValidDateTimeStrings (${valueToString(input)})`, () => {

            expect(TestType.isValidDateTime(input as unknown as string)).toBeTruthy();
        });
    });

    MockData.String.Invalid.List.forEach(input => {
        it(`should validate InvalidStringList (${valueToString(input)})`, () => {

            expect(TestType.isValidString(input)).toBeFalsy();
        });
    });

    MockData.Number.Invalid.List.forEach(input => {
        it(`should validate InvalidNumberList (${valueToString(input)})`, () => {

            expect(TestType.isValidNumberInput(input)).toBeFalsy();
        });
    });


    MockData.JSON.Invalid.List.forEach(input => {
        it(`should validate InvalidJsonObjectStringList (${valueToString(input)})`, () => {
            expect(TestType.isValidJsonString(input)).toBeFalsy();
        });
    });

    MockData.Number.Valid.List.forEach(input => {


        it(`should validate ValidIntegerList (${valueToString(input)})`, () => {
            expect(TestType.isValidNumberInput(input)).toBeTruthy();
        });
    });

    it('should validate CircularReference', () => {
        expect(TestType.isCircularReference(MockData.Misc.CircularReference)).toBeTruthy();
    });

    MockData.JSON.Valid.List.forEach(input => {
        it(`should validate ValidJsonStrings (${valueToString(input)})`, () => {
            expect(TestType.isValidJsonString(input)).toBeTruthy();
        });
    });

    MockData.Number.Valid.BoundaryValueList.forEach(input => {
        it(`should validate BoundaryValues (${valueToString(input)})`, () => {
            expect(TestType.isBoundaryValue(input)).toBeTruthy();
        });
    });

    MockData.String.Invalid.ThatAreNotObjectStringList.forEach(input => {
        it(`should validate StringsThatAreNotObjectStrings (${valueToString(input)})`, () => {
            expect(TestType.isNonObjectJson(input)).toBeTruthy();
        });
    });

    MockData.Number.Valid.List.forEach(input => {
        it(`should validate NumberTypes (${valueToString(input)})`, () => {
            expect(TestType.isNumberType(input)).toBeTruthy();
        });
    });

    it('should validate other MockData fields', () => {

        expect(typeof MockData.String.Valid.Value).toBe('string');
        expect(typeof MockData.Number.Valid.Value).toBe('number');
        expect(typeof MockData.Date.Valid.Value  ).toBe('object');
        expect(typeof MockData.RootUserId        ).toBe('number');
        expect(MockData.String.Valid.Empty       ).toBe('');
        expect(MockData.Undefined                ).toBeUndefined();
        expect(MockData.Null                     ).toBeNull();
    });
});

